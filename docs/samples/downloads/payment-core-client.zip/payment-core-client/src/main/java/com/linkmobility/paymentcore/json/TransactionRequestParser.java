package com.linkmobility.paymentcore.json;


import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import com.eclipsesource.json.JsonValue;
import com.linkmobility.paymentcore.dto.transactions.TransactionRequest;
import com.linkmobility.paymentcore.exceptions.JsonParserException;

public class TransactionRequestParser {

    public byte[] toJson(TransactionRequest req) {
        try {
            JsonObject object = Json.object();
            object.add("partnerId", req.getPartnerId());
            object.add("currency", req.getCurrency());
            object.add("paymentProvider", req.getPaymentProvider().getName());

            if (req.getAmount() != null) object.add("amount", req.getAmount().toString());
            if (req.getReturnUrl() != null) object.add("returnUrl", req.getReturnUrl());
            if (req.getStatusCallbackUrl() != null) object.add("statusCallbackUrl", req.getStatusCallbackUrl());
            if (req.getReferenceId() != null) object.add("referenceId", req.getReferenceId());
            if (req.getPaymentEntity() != null) object.add("paymentEntity", req.getPaymentEntity());
            if (req.getDescription() != null) object.add("description", req.getDescription());
            if (req.getTransactionReconRef() != null) object.add("transactionReconRef", req.getTransactionReconRef());
            return object.toString().getBytes("UTF-8");
        } catch (Exception e) {
            throw new JsonParserException("Json parser for TransactionRequest failed!", e);
        }
    }
}
