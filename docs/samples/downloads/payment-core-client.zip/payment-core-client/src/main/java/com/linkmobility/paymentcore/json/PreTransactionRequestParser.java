package com.linkmobility.paymentcore.json;


import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import com.linkmobility.paymentcore.dto.pretransactions.PreTransactionRequest;
import com.linkmobility.paymentcore.exceptions.JsonParserException;
import com.linkmobility.paymentcore.utils.Utils;


public class PreTransactionRequestParser {


    public static byte[] toJson(PreTransactionRequest req) {

        try {
            JsonObject object = Json.object();

            object.add("partnerId", req.getPartnerId());
            object.add("msisdn", req.getMsisdn());
            if (req.getExpiryDate() != null) object.add("expiryUtc", Utils.toUtcDateString(req.getExpiryDate()));
            if (req.getCorrelationId() != null) object.add("correlationId", req.getCorrelationId());
            if (req.getViewTemplateName() != null) object.add("viewTemplateName", req.getViewTemplateName());
            if (req.getReturnUrl() != null) object.add("returnUrl", req.getReturnUrl());
            if (req.getStatusCallbackUrl() != null) object.add("statusCallbackUrl", req.getStatusCallbackUrl());
            if (req.getSmsStatusCallbackUrl() != null)
                object.add("smsStatusCallbackUrl", req.getSmsStatusCallbackUrl());
            if (req.getReferenceId() != null) object.add("referenceId", req.getReferenceId());
            if (req.getTransactionReconRef() != null) object.add("ocr", req.getTransactionReconRef());
            if (req.getSmsNotificationOriginator() != null)
                object.add("smsNotificationOriginator", req.getSmsNotificationOriginator());
            if (req.getSmsNotificationText() != null) object.add("smsNotificationText", req.getSmsNotificationText());
            if (req.getSmsNotificationSendDate() != null)
                object.add("smsNotificationSendTimeUtc", Utils.toUtcDateString(req.getSmsNotificationSendDate()));
            if (req.getDescription() != null) object.add("description", req.getDescription());
            if (req.getCurrency() != null) object.add("currency", req.getCurrency());
            if (req.getAmount() != null) object.add("amount", req.getAmount().toString());

            JsonArray providers = Json.array().asArray();
            object.add("paymentProviders", providers);
            req.getPaymentProviders().forEach(p -> {
                providers.add(p.getName());
            });

            if (req.getCampaignId() > 0) object.add("campaignId", req.getCampaignId());
            if (req.getAuthentication() != null) {
                JsonObject authentication = Json.object();
                object.add("authentication", authentication);
                if (req.getAuthentication().getSocialSecurityNumber() != null)
                    authentication.add("socialSecurityNumber", req.getAuthentication().getSocialSecurityNumber());
                if (req.getAuthentication().getAuthenticationMethods() != null) {
                    JsonArray methods = Json.array().asArray();
                    object.add("authenticationMethods", methods);
                    req.getAuthentication().getAuthenticationMethods().forEach(methods::add);
                }
            }
            if (req.getCustomProperties() != null) {
                JsonObject properties = Json.object();
                object.add("customProperties", properties);
                req.getCustomProperties().forEach(properties::add);
            }
            if (req.getAccessedURLDate() != null) object.add("accessedURLDateUtc", Utils.toUtcDateString(req.getAccessedURLDate()));
            return object.toString().getBytes("UTF-8");
        } catch (Exception e) {
            throw new JsonParserException("Json parser for PreTransactionRequest failed!", e);
        }
    }
}
