package com.linkmobility.paymentcore.utils;


import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.TimeZone;
import java.util.UUID;


/**
 * <h1>Utility class</h1>
 *
 * For internal use.
 */
public class Utils {

    private static SimpleDateFormat utc = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");

    /**
     * Creates Hmac Authorization string
     *
     * @param partnerId     authorized partner
     * @param secretKey     secret key
     * @param url           url to be called
     * @param method        http method GET / POST
     * @param payload       payload in case of POST
     * @return              authorization header string
     */
    public static String createAuthorizationHeader(String partnerId, String secretKey, String url, String method, Payload payload) {
        try {
            final Long timestamp = new Date().getTime() / 1000;
            final String nonce = UUID.randomUUID().toString();
            String base64encodedPayload = "";

            if (payload != null) {
                MessageDigest md = MessageDigest.getInstance("MD5");
                byte[] contentBytes = payload.getContent();
                byte[] a = md.digest(contentBytes);
                base64encodedPayload = Base64.getEncoder().encodeToString(a);
            }
            String data = partnerId + method + URLEncoder.encode((url).toLowerCase(), "UTF-8") + timestamp + nonce + base64encodedPayload;
            SecretKeySpec signingKey = new SecretKeySpec(Base64.getDecoder().decode(secretKey.getBytes()), "HmacSHA256");
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(signingKey);
            byte[] fullHash = mac.doFinal(data.getBytes("UTF-8"));
            String signedHash = Base64.getEncoder().encodeToString(fullHash).substring(0, 10);
            return "hmac \"" + partnerId + ":" + signedHash + ":" + nonce + ":" + timestamp + "\"";
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage());
        }
    }

    /**
     * Transforms UTC date string returned by API to date object
     *
     * @param   date    represents UTC date string as returned by API
     * @return          java.util.date
     */
    public static Date fromUtcDateString(String date) {
        try {
            if (date == null) return null;
            return utc.parse(date);
        } catch (Exception ignore) {
            return null;
        }
    }

    /**
     * Transforms date object to UTC date string
     *
     * @param date  date
     * @return      UTC date string required by API
     */
    public static String toUtcDateString(Date date) {
        utc.setTimeZone(TimeZone.getTimeZone("UTC"));
        return utc.format(date);
    }
}
