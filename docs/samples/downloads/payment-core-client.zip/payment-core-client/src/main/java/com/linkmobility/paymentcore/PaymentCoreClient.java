package com.linkmobility.paymentcore;

import com.linkmobility.paymentcore.dto.pretransactions.PreTransactionLink;
import com.linkmobility.paymentcore.dto.pretransactions.PreTransactionRequest;
import com.linkmobility.paymentcore.dto.pretransactions.PreTransactionResponse;
import com.linkmobility.paymentcore.dto.transactions.TransactionRequest;
import com.linkmobility.paymentcore.dto.transactions.TransactionResponse;
import com.linkmobility.paymentcore.exceptions.HttpConnectionException;
import com.linkmobility.paymentcore.json.*;
import com.linkmobility.paymentcore.utils.Payload;
import com.linkmobility.paymentcore.utils.Utils;
import org.asynchttpclient.AsyncHttpClient;
import org.asynchttpclient.DefaultAsyncHttpClient;
import org.asynchttpclient.DefaultAsyncHttpClientConfig;
import org.asynchttpclient.Response;

import java.util.List;
import java.util.concurrent.*;

/**
 *  <h1>Java client for Payment Core API</h1>
 *
 *  @author Lukas Bem
 *  @version 1.0
 *  @since 1.8
 */
public class PaymentCoreClient {

    private static final String API_URL = "http://pay-core.linkmobility.com/api";

    private String partnerId;
    private String secretKey;
    private AsyncHttpClient client;


    /**
     * Constructor for the PaymentCoreClientAsync. Sets the partnerId and secretKey and initiates HttpClient instance.
     *
     * @param partnerId id of a partner for Payment Core API
     * @param secretKey key associated with the partner id
     */
    public PaymentCoreClient(String partnerId, String secretKey) {
        this.partnerId = partnerId;
        this.secretKey = secretKey;
        DefaultAsyncHttpClientConfig.Builder builder = new DefaultAsyncHttpClientConfig.Builder();
        builder.setMaxRequestRetry(3);
        builder.setFollowRedirect(false);
        client = new DefaultAsyncHttpClient(builder.build());
    }

    /**
     * Gets pre-transaction links associated with the given correlation id. Supports ODATA.
     *
     * @param correlationId         correlation id
     * @param skip                  elements to skip
     * @param top                   maximum elements to return, ignored if 0
     * @return                      list of {@link PreTransactionLink}
     * @throws CompletionException  exception thrown into the CompletableFuture block
     */
    public CompletableFuture<List<PreTransactionLink>> getPreTransactions(String correlationId, int skip, int top) {
        StringBuilder url = new StringBuilder(API_URL + "/pre-transactions?partnerId=").append(partnerId)
                .append("&correlationId=").append(correlationId).append("&api-version=2.0");
        if (skip > 0) url.append("&$skip=").append(skip);
        if (top > 0) url.append("&$top=").append(top);

        return execute(url.toString(), null)
                .thenApply(Response::getResponseBody)
                .thenApply(PreTransactionLinkParser::fromJson);
    }

    /**
     * Creates a new pre-transaction.
     *
     * @param       preTransactionRequest     {@link PreTransactionRequest}
     * @return                                pre-transaction id
     * @throws      CompletionException       exception thrown into the CompletableFuture block
     */
    public CompletableFuture<String> createPreTransaction(PreTransactionRequest preTransactionRequest) {
        String url = API_URL + "/pre-transactions?api-version=2.0";
        Payload payload = new Payload("application/json", PreTransactionRequestParser.toJson(preTransactionRequest));

        return execute(url.toString(), payload).thenApply(this::getIdFromLocation);
    }

    /**
     * Gets a pre-transaction by id.
     *
     * @param       preTransactionId        pre-transaction id
     * @return                              {@link PreTransactionResponse}
     * @throws      CompletionException     exception thrown into the CompletableFuture block
     */
    public CompletableFuture<PreTransactionResponse> getPreTransaction(String preTransactionId) {
        StringBuilder url = new StringBuilder(API_URL + "/pre-transactions/").append(partnerId)
                .append("/").append(preTransactionId).append("?api-version=2.0");

        return execute(url.toString(), null)
                .thenApply(Response::getResponseBody)
                .thenApply(PreTransactionResponseParser::fromJson);
    }

    /**
     * Creates a new transaction.
     *
     * @param       transactionRequest    {@link TransactionRequest}
     * @return      transaction id
     * @throws      CompletionException   exception thrown into the CompletableFuture block
     */
    public CompletableFuture<String> createTransaction(TransactionRequest transactionRequest) {
        StringBuilder url = new StringBuilder(API_URL + "/transactions").append("?api-version=2.0");
        Payload payload = new Payload("application/json", new TransactionRequestParser().toJson(transactionRequest));

        return execute(url.toString(), payload).thenApply(this::getIdFromLocation);
    }

    /**
     * Verifies a phone transaction with pincode.
     *
     * @param transactionId transaction id
     * @param pinCode       pincode
     * @return ???
     * @throws UnsupportedOperationException
     */
    public CompletableFuture<String> verifyPhoneTransaction(String transactionId, String pinCode) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    /**
     *  Gets transaction by client reference id. This method handles internal redirect by blocking while waiting for
     *  the redirect http response and it's location header. Therefor the CompletionException should be caught from
     *  the main thread as well as from the CompletableFuture block using .exceptionally stage
     *
     * @param   referenceId             transaction reference id
     * @return                          {@link TransactionResponse}
     * @throws CompletionException      exception thrown into the CompletableFuture block
     */
    public CompletableFuture<TransactionResponse> getTransactionByReferenceId(String referenceId) {
        StringBuilder url = new StringBuilder(API_URL + "/transactions?partnerId=").append(partnerId)
                .append("&referenceId=").append(referenceId).append("&api-version=2.0");

        try {
            //expecting redirect, join is called to capture it
            Response response = execute(url.toString(), null).join();
            return CompletableFuture.supplyAsync(() -> response)
                    .thenApply(Response::getResponseBody)
                    .thenApply(TransactionResponseParser::fromJson);
        } catch (CompletionException e) {
            if (e.getCause() instanceof HttpConnectionException) {
                if (((HttpConnectionException) e.getCause()).getHttpStatusCode() == 302) {
                    return execute(((HttpConnectionException) e.getCause()).getResponseBody(), null)
                            .thenApply(Response::getResponseBody)
                            .thenApply(TransactionResponseParser::fromJson);
                }
            }
            throw e;
        }
    }

    /**
     * Gets transaction by transaction id.
     *
     * @param       transactionId           transaction id
     * @return                              {@link TransactionResponse}
     * @throws      CompletionException     exception thrown into the CompletableFuture block
     */
    public CompletableFuture<TransactionResponse> getTransaction(String transactionId) {
        StringBuilder url = new StringBuilder(API_URL + "/transactions/").append(partnerId)
                .append("/").append(transactionId).append("?api-version=2.0");

        return execute(url.toString(), null)
                .thenApply(Response::getResponseBody)
                .thenApply(TransactionResponseParser::fromJson);
    }

    private CompletableFuture<Response> execute(String url, Payload payload) {
        if (payload != null) {
            return client.preparePost(url).addHeader("Authorization", Utils.createAuthorizationHeader(partnerId, secretKey, url, "POST", payload))
                    .setBody(payload.getContent())
                    .addHeader("Content-Type", payload.getMimeType())
                    .execute()
                    .toCompletableFuture()
                    .thenApply(this::checkResponse);
        }
        else {
            return client.prepareGet(url).addHeader("Authorization", Utils.createAuthorizationHeader(partnerId, secretKey, url, "GET", null))
                    .execute()
                    .toCompletableFuture()
                    .thenApply(this::checkResponse);
        }
    }

    private Response checkResponse(Response response) {
        if (response.isRedirected())
            throw new HttpConnectionException(response.getStatusCode(), response.getHeader("Location"));
        if (response.getStatusCode() < 200 || response.getStatusCode() > 299) {
            throw new HttpConnectionException(response.getStatusCode(), response.getResponseBody());
        }
        return response;
    }

    private String getIdFromLocation(Response response) {
        String location = response.getHeader("Location");
        return location.substring(location.lastIndexOf("/") + 1, location.lastIndexOf("?"));
    }
}