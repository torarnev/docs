package com.linkmobility.paymentcore.dto.pretransactions;


public class PreTransactionResponse extends PreTransactionRequest {

    private String preTransactionId;
    private boolean smsNotificationSent;
    private boolean smsNotificationDelivered;

    public String getPreTransactionId() {
        return preTransactionId;
    }

    public void setPreTransactionId(String preTransactionId) {
        this.preTransactionId = preTransactionId;
    }

    public boolean isSmsNotificationSent() {
        return smsNotificationSent;
    }

    public void setSmsNotificationSent(boolean smsNotificationSent) {
        this.smsNotificationSent = smsNotificationSent;
    }

    public boolean isSmsNotificationDelivered() {
        return smsNotificationDelivered;
    }

    public void setSmsNotificationDelivered(boolean smsNotificationDelivered) {
        this.smsNotificationDelivered = smsNotificationDelivered;
    }

    @Override
    public String toString() {
        return super.toString() + "%%PreTransactionResponse{" +
                "preTransactionId='" + preTransactionId + '\'' +
                ", smsNotificationSent=" + smsNotificationSent +
                ", smsNotificationDelivered=" + smsNotificationDelivered +
                '}';
    }
}
