package com.linkmobility.paymentcore.dto.pretransactions;

import com.linkmobility.paymentcore.dto.PaymentProvider;

import java.math.BigDecimal;
import java.util.*;

public class PreTransactionRequest {

    public PreTransactionRequest() {}

    private int partnerId;
    private Date expiryDate;
    private String correlationId;
    private String viewTemplateName;
    private String returnUrl;
    private String statusCallbackUrl;
    private String smsStatusCallbackUrl;
    private String referenceId;
    private String transactionReconRef;
    private String msisdn;
    private String smsNotificationOriginator;
    private String smsNotificationText;
    private Date smsNotificationSendDate;
    private String description;
    private String currency;
    private BigDecimal amount;
    private List<PaymentProvider> paymentProviders;
    private int campaignId;
    private Authentication authentication;
    private Map<String, String> customProperties;
    private Date accessedURLDate;

    public int getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(int partnerId) {
        this.partnerId = partnerId;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getViewTemplateName() {
        return viewTemplateName;
    }

    public void setViewTemplateName(String viewTemplateName) {
        this.viewTemplateName = viewTemplateName;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    public String getStatusCallbackUrl() {
        return statusCallbackUrl;
    }

    public void setStatusCallbackUrl(String statusCallbackUrl) {
        this.statusCallbackUrl = statusCallbackUrl;
    }

    public String getSmsStatusCallbackUrl() {
        return smsStatusCallbackUrl;
    }

    public void setSmsStatusCallbackUrl(String smsStatusCallbackUrl) {
        this.smsStatusCallbackUrl = smsStatusCallbackUrl;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public String getTransactionReconRef() {
        return transactionReconRef;
    }

    public void setTransactionReconRef(String transactionReconRef) {
        this.transactionReconRef = transactionReconRef;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getSmsNotificationOriginator() {
        return smsNotificationOriginator;
    }

    public void setSmsNotificationOriginator(String smsNotificationOriginator) {
        this.smsNotificationOriginator = smsNotificationOriginator;
    }

    public String getSmsNotificationText() {
        return smsNotificationText;
    }

    public void setSmsNotificationText(String smsNotificationText) {
        this.smsNotificationText = smsNotificationText;
    }

    public Date getSmsNotificationSendDate() {
        return smsNotificationSendDate;
    }

    public void setSmsNotificationSendDate(Date smsNotificationSendDate) {
        this.smsNotificationSendDate = smsNotificationSendDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public List<PaymentProvider> getPaymentProviders() {
        return paymentProviders;
    }

    public void setPaymentProviders(List<PaymentProvider> paymentProviders) {
        this.paymentProviders = paymentProviders;
    }

    public int getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(int campaignId) {
        this.campaignId = campaignId;
    }

    public Authentication getAuthentication() {
        return authentication;
    }

    public void setAuthentication(Authentication authentication) {
        this.authentication = authentication;
    }

    public Map<String, String> getCustomProperties() {
        return customProperties;
    }

    public void setCustomProperties(Map<String, String> customProperties) {
        this.customProperties = customProperties;
    }

    public Date getAccessedURLDate() {
        return accessedURLDate;
    }

    public void setAccessedURLDate(Date accessedURLDate) {
        this.accessedURLDate = accessedURLDate;
    }

    @Override
    public String toString() {
        return "PreTransactionRequest{" +
                "partnerId=" + partnerId +
                ", expiryUtc='" + expiryDate + '\'' +
                ", correlationId='" + correlationId + '\'' +
                ", viewTemplateName='" + viewTemplateName + '\'' +
                ", returnUrl='" + returnUrl + '\'' +
                ", statusCallbackUrl='" + statusCallbackUrl + '\'' +
                ", smsStatusCallbackUrl='" + smsStatusCallbackUrl + '\'' +
                ", referenceId='" + referenceId + '\'' +
                ", transactionReconRef='" + transactionReconRef + '\'' +
                ", msisdn='" + msisdn + '\'' +
                ", smsNotificationOriginator='" + smsNotificationOriginator + '\'' +
                ", smsNotificationText='" + smsNotificationText + '\'' +
                ", smsNotificationSendTimeUtc='" + smsNotificationSendDate + '\'' +
                ", description='" + description + '\'' +
                ", currency='" + currency + '\'' +
                ", amount=" + amount +
                ", paymentProviders=" + paymentProviders +
                ", campaignId=" + campaignId +
                ", authentication=" + authentication +
                ", customProperties=" + customProperties +
                ", accessedURLDate='" + accessedURLDate + '\'' +
                '}';
    }
}
