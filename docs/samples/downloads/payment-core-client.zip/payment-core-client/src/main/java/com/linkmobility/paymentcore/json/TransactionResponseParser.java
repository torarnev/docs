package com.linkmobility.paymentcore.json;


import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import com.eclipsesource.json.JsonValue;
import com.linkmobility.paymentcore.dto.PaymentProvider;
import com.linkmobility.paymentcore.dto.transactions.PaymentSetup;
import com.linkmobility.paymentcore.dto.transactions.TransactionResponse;
import com.linkmobility.paymentcore.exceptions.JsonParserException;
import com.linkmobility.paymentcore.utils.Utils;

import java.math.BigDecimal;
import java.util.ArrayList;

public class TransactionResponseParser {

    public static TransactionResponse fromJson(String json) {
        try {
            TransactionResponse res = new TransactionResponse();
            JsonValue value = Json.parse(json);
            JsonObject object = value.asObject();
            res.setPartnerId(object.getInt("partnerId", 0));
            res.setCurrency(object.getString("currency", null));
            res.setTransactionId(object.getString("transactionId", null));
            res.setCreatedDate(Utils.fromUtcDateString(object.getString("createdDateUtc", null)));
            res.setPaymentTransactionId(object.getString("paymentTransactionId", null));
            res.setStatus(object.getString("status", null));
            res.setSuccess(object.getBoolean("success", false));
            res.setStatusDescription(object.getString("statusDescription", null));
            res.setStatusCode(object.getString("statusCode", null));
            if (object.get("paymentSetup") != null) {
                PaymentSetup paymentSetup = new PaymentSetup();
                JsonObject payment = object.get("paymentSetup").asObject();
                paymentSetup.setMethod(payment.getString("method", null));
                paymentSetup.setUrl(payment.getString("url", null));
                if (payment.get("fields") != null) {
                    paymentSetup.setFields(new ArrayList<>());
                    JsonArray fields = payment.get("fields").asArray();
                    fields.forEach(paymentSetup.getFields()::add);
                }
                res.setPaymentSetup(paymentSetup);
            }
            res.setAmount(new BigDecimal(object.getFloat("amount", 0)).setScale(2, BigDecimal.ROUND_HALF_UP));
            res.setReturnUrl(object.getString("returnUrl", null));
            res.setStatusCallbackUrl(object.getString("statusCallbackUrl", null));
            res.setReferenceId(object.getString("referenceId", null));
            res.setPaymentProvider(new PaymentProvider(object.getString("paymentProvider", null)));
            res.setPaymentEntity(object.getString("paymentEntity", null));
            res.setDescription(object.getString("description", null));
            res.setTransactionReconRef(object.getString("transactionReconRef", null));
            return res;
        } catch (Exception e) {
            throw new JsonParserException("Json parser for TransactionResponseParser failed!: " + json, e);
        }
    }
}
