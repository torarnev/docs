package com.linkmobility.paymentcore.utils;


/**
 * <h1>Payload</h1>
 *
 * Internal use.
 */
public class Payload {

    private String mimeType;
    private byte[] content;

    public Payload(String mimeType, byte[] content) {
        this.mimeType = mimeType;
        this.content = content;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public byte[] getContent() {
        return content;
    }

    public void setContent(byte[] content) {
        this.content = content;
    }
}
