package com.linkmobility.paymentcore.exceptions;


/**
 * <h1>JsonParserException</h1>
 * Thrown on serialization / deserialization errors.
 */
public class JsonParserException extends RuntimeException {

    /**
     * Contructor for easy creation
     *
     * @param message       error message
     * @param cause         cause exception
     */
    public JsonParserException(String message, Throwable cause) {
        super(message, cause);
    }
}
