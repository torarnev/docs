package com.linkmobility.paymentcore.dto.transactions;


import java.util.Date;

public class TransactionResponse extends TransactionRequest {

    private String transactionId;
    private Date createdDate;
    private String paymentTransactionId;
    private String status;
    private boolean success;
    private String statusDescription;
    private String statusCode;
    private PaymentSetup paymentSetup;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getPaymentTransactionId() {
        return paymentTransactionId;
    }

    public void setPaymentTransactionId(String paymentTransactionId) {
        this.paymentTransactionId = paymentTransactionId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getStatusDescription() {
        return statusDescription;
    }

    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public PaymentSetup getPaymentSetup() {
        return paymentSetup;
    }

    public void setPaymentSetup(PaymentSetup paymentSetup) {
        this.paymentSetup = paymentSetup;
    }

    @Override
    public String toString() {
        return super.toString() + "%%%TransactionResponse{" +
                "transactionId='" + transactionId + '\'' +
                ", createdDate='" + createdDate + '\'' +
                ", paymentTransactionId='" + paymentTransactionId + '\'' +
                ", status='" + status + '\'' +
                ", success=" + success +
                ", statusDescription='" + statusDescription + '\'' +
                ", statusCode='" + statusCode + '\'' +
                ", paymentSetup=" + paymentSetup +
                '}';
    }
}
