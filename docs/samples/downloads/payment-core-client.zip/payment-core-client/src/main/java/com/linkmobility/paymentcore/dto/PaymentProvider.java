package com.linkmobility.paymentcore.dto;


import java.util.HashMap;
import java.util.Map;

/**
 * Payment Provider
 *
 */
public class PaymentProvider {

    /**
     * Constructor
     * @param   name    name of the provider(phone, nets, avtalegiro...)
     */
    public PaymentProvider(String name) {
        this.name = name;
    }

    private String name;


    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "PaymentProvider{" +
                "name='" + name + '\'' +
                '}';
    }
}
