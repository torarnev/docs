package com.linkmobility.paymentcore.dto.pretransactions;


import java.util.List;

public class PreTransactionImportResult {

    private boolean success;
    private int succeededEntries;
    private int failedEntries;
    private List<String> errors;
    private String href;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public int getSucceededEntries() {
        return succeededEntries;
    }

    public void setSucceededEntries(int succeededEntries) {
        this.succeededEntries = succeededEntries;
    }

    public int getFailedEntries() {
        return failedEntries;
    }

    public void setFailedEntries(int failedEntries) {
        this.failedEntries = failedEntries;
    }

    public List<String> getErrors() {
        return errors;
    }

    public void setErrors(List<String> errors) {
        this.errors = errors;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    @Override
    public String toString() {
        return "PreTransactionImportResult{" +
                "success=" + success +
                ", succeededEntries=" + succeededEntries +
                ", failedEntries=" + failedEntries +
                ", errors=" + errors +
                ", href='" + href + '\'' +
                '}';
    }
}
