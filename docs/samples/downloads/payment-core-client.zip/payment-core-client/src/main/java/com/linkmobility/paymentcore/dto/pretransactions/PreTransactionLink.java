package com.linkmobility.paymentcore.dto.pretransactions;


import java.math.BigDecimal;

public class PreTransactionLink {

    private String preTransactionId;
    private String correlationId;
    private String msisdn;
    private String currency;
    private BigDecimal amount;

    public String getPreTransactionId() {
        return preTransactionId;
    }

    public void setPreTransactionId(String preTransactionId) {
        this.preTransactionId = preTransactionId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "PreTransactionLink{" +
                "preTransactionId='" + preTransactionId + '\'' +
                ", correlationId='" + correlationId + '\'' +
                ", msisdn='" + msisdn + '\'' +
                ", currency='" + currency + '\'' +
                ", amount=" + amount +
                '}';
    }
}
