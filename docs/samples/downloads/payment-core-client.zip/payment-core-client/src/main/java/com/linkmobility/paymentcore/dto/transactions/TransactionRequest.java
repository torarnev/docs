package com.linkmobility.paymentcore.dto.transactions;

import com.linkmobility.paymentcore.dto.PaymentProvider;

import java.math.BigDecimal;

public class TransactionRequest {

    private int partnerId;
    private String currency;
    private BigDecimal amount;
    private String returnUrl;
    private String statusCallbackUrl;
    private String referenceId;
    private PaymentProvider paymentProvider;
    private String paymentEntity;
    private String description;
    private String transactionReconRef;

    public int getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(int partnerId) {
        this.partnerId = partnerId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getReturnUrl() {
        return returnUrl;
    }

    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    public String getStatusCallbackUrl() {
        return statusCallbackUrl;
    }

    public void setStatusCallbackUrl(String statusCallbackUrl) {
        this.statusCallbackUrl = statusCallbackUrl;
    }

    public String getReferenceId() {
        return referenceId;
    }

    public void setReferenceId(String referenceId) {
        this.referenceId = referenceId;
    }

    public PaymentProvider getPaymentProvider() {
        return paymentProvider;
    }

    public void setPaymentProvider(PaymentProvider paymentProvider) {
        this.paymentProvider = paymentProvider;
    }

    public String getPaymentEntity() {
        return paymentEntity;
    }

    public void setPaymentEntity(String paymentEntity) {
        this.paymentEntity = paymentEntity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTransactionReconRef() {
        return transactionReconRef;
    }

    public void setTransactionReconRef(String transactionReconRef) {
        this.transactionReconRef = transactionReconRef;
    }


    @Override
    public String toString() {
        return "TransactionRequest{" +
                "partnerId=" + partnerId +
                ", currency='" + currency + '\'' +
                ", amount=" + amount +
                ", returnUrl='" + returnUrl + '\'' +
                ", statusCallbackUrl='" + statusCallbackUrl + '\'' +
                ", referenceId='" + referenceId + '\'' +
                ", paymentProvider=" + paymentProvider +
                ", paymentEntity='" + paymentEntity + '\'' +
                ", description='" + description + '\'' +
                ", transactionReconRef='" + transactionReconRef + '\'' +
                '}';
    }
}
