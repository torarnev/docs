package com.linkmobility.paymentcore.exceptions;


/**
 * <h1>HttpConnectionException</h1>
 * Thrown in case of http failures of the Payment Core API.
 */
public class HttpConnectionException extends RuntimeException {

    private int httpStatusCode;
    private String responseBody;

    /**
     * Constructor for easy creation
     *
     * @param   httpStatusCode      status code
     * @param   responseBody        response body
     */
    public HttpConnectionException(int httpStatusCode, String responseBody) {
        super("Status Code: " + httpStatusCode + ", Response Body: " + responseBody);
        this.httpStatusCode = httpStatusCode;
        this.responseBody = responseBody;
    }

    public HttpConnectionException(String message, Throwable cause) {
        super(message, cause);
    }

    public HttpConnectionException(Throwable cause) {
        super(cause);
    }

    public int getHttpStatusCode() {
        return httpStatusCode;
    }

    public String getResponseBody() {
        return responseBody;
    }
}
