package com.linkmobility.paymentcore.json;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import com.eclipsesource.json.JsonValue;
import com.linkmobility.paymentcore.dto.pretransactions.PreTransactionLink;
import com.linkmobility.paymentcore.exceptions.JsonParserException;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PreTransactionLinkParser {

    public static List<PreTransactionLink> fromJson(String json) {
        try {
            List<PreTransactionLink> result = new ArrayList<>();
            JsonValue value = Json.parse(json);
            JsonArray array = value.asArray();
            array.forEach(v -> {
                PreTransactionLink link = new PreTransactionLink();
                JsonObject obj = v.asObject();
                link.setPreTransactionId(obj.getString("preTransactionId", null));
                link.setCorrelationId(obj.getString("correlationId", null));
                link.setMsisdn(obj.getString("msisdn", null));
                link.setCurrency(obj.getString("currency", null));
                link.setAmount(new BigDecimal(obj.getFloat("amount", 0)).setScale(2, BigDecimal.ROUND_HALF_UP));
                result.add(link);
            });
            return result;
        } catch (Exception e) {
            throw new JsonParserException("Json parser for PreTransactionRequest failed!", e);
        }
    }
}
