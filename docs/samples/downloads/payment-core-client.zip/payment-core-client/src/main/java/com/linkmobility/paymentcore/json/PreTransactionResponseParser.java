package com.linkmobility.paymentcore.json;

import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import com.eclipsesource.json.JsonValue;
import com.linkmobility.paymentcore.dto.*;
import com.linkmobility.paymentcore.dto.pretransactions.Authentication;
import com.linkmobility.paymentcore.dto.pretransactions.PreTransactionResponse;
import com.linkmobility.paymentcore.exceptions.JsonParserException;
import com.linkmobility.paymentcore.utils.Utils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PreTransactionResponseParser {

    public static PreTransactionResponse fromJson(String json) {
        try {
            PreTransactionResponse res = new PreTransactionResponse();
            JsonValue value = Json.parse(json);
            JsonObject object = value.asObject();
            res.setPartnerId(object.getInt("partnerId", 0));
            res.setMsisdn(object.getString("msisdn", null));
            res.setPreTransactionId(object.getString("preTransactionId", null));
            res.setSmsNotificationSent(object.getBoolean("smsNotificationSent", false));
            res.setSmsNotificationDelivered(object.getBoolean("smsNotificationDelivered", false));
            res.setExpiryDate(Utils.fromUtcDateString(object.getString("expiryUtc", null)));
            res.setCorrelationId(object.getString("correlationId", null));
            res.setViewTemplateName(object.getString("viewTemplateName", null));
            res.setReturnUrl(object.getString("returnUrl", null));
            res.setStatusCallbackUrl(object.getString("statusCallbackUrl", null));
            res.setSmsStatusCallbackUrl(object.getString("smsStatusCallbackUrl", null));
            res.setReferenceId(object.getString("referenceId", null));
            res.setTransactionReconRef(object.getString("transactionReconRef", null));
            res.setSmsNotificationOriginator(object.getString("smsNotificationOriginator", null));
            res.setSmsNotificationText(object.getString("smsNotificationText",  null));
            res.setDescription(object.getString("description", null));
            res.setCurrency(object.getString("currency", null));
            res.setAmount(new BigDecimal(object.getFloat("amount", 0)).setScale(2, BigDecimal.ROUND_HALF_UP));
            if (object.get("paymentProviders") != null) {
                List<PaymentProvider> providers = new ArrayList<>();
                JsonArray paymentProviders = object.get("paymentProviders").asArray();
                paymentProviders.forEach(x -> {
                    providers.add(new PaymentProvider(x.asString()));
                });
                res.setPaymentProviders(providers);
            }
            res.setCampaignId(object.getInt("campaignId", 0));
            if (object.get("authentication") != null) {
                Authentication authentication = new Authentication();
                JsonObject auth = object.get("authentication").asObject();
                authentication.setSocialSecurityNumber(auth.getString("socialSecurityNumber", null));
                if (object.get("authenticationMethods") != null) {
                    authentication.setAuthenticationMethods(new ArrayList<>());
                    JsonArray methods = object.get("authenticationMethods").asArray();
                    methods.forEach(m -> authentication.getAuthenticationMethods().add(m.asString()));
                }
                res.setAuthentication(authentication);
            }
            if (object.get("customProperties") != null) {
                Map<String, String> customProperties = new HashMap<>();
                JsonObject properties = object.get("customProperties").asObject();
                properties.forEach(p -> {
                    String v = p.getValue().isString() ? p.getValue().asString() : p.getValue().toString();
                    customProperties.put(p.getName(), v);
                });
                res.setCustomProperties(customProperties);
            }
            res.setAccessedURLDate(Utils.fromUtcDateString(object.getString("accessedURLDateUtc", null)));
            return res;
        } catch (Exception e) {
            throw new JsonParserException("Json parser for PreTransactionResponseParser failed!", e);
        }
    }
}
