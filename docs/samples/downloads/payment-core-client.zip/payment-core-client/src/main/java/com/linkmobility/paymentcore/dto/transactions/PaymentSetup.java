package com.linkmobility.paymentcore.dto.transactions;


import java.util.List;

public class PaymentSetup {

    private boolean async;
    private String url;
    private String method;
    private List<Object> fields;

    public boolean isAsync() {
        return async;
    }

    public void setAsync(boolean async) {
        this.async = async;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public List<Object> getFields() {
        return fields;
    }

    public void setFields(List<Object> fields) {
        this.fields = fields;
    }

    @Override
    public String toString() {
        return "PaymentSetup{" +
                "async=" + async +
                ", url='" + url + '\'' +
                ", method='" + method + '\'' +
                ", fields=" + fields +
                '}';
    }
}
