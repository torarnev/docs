package com.linkmobility.paymentcore.json;


import com.eclipsesource.json.Json;
import com.eclipsesource.json.JsonArray;
import com.eclipsesource.json.JsonObject;
import com.linkmobility.paymentcore.dto.pretransactions.PreTransactionImportResult;
import com.linkmobility.paymentcore.exceptions.JsonParserException;

import java.util.ArrayList;
import java.util.List;

public class PreTransactionImportResultParser {

    public PreTransactionImportResult fromJson(String json) {
        try {
            PreTransactionImportResult result = new PreTransactionImportResult();
            JsonObject object = Json.parse(json).asObject();
            result.setSuccess(object.getBoolean("success", false));
            result.setSucceededEntries(object.getInt("succeededEntries", 0));
            result.setFailedEntries(object.getInt("failedEntries", 0));
            if (object.get("Errors") != null) {
                List<String> errors = new ArrayList<>();
                JsonArray err = object.get("Errors").asArray();
                err.forEach(e -> errors.add(e.asString()));
                result.setErrors(errors);
            }
            result.setHref(object.getString("href", null));
            return result;
        } catch (Exception e) {
            throw new JsonParserException("Json parser for PreTransactionImport failed!", e);
        }
    }
}
