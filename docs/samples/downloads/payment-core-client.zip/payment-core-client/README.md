Java Payment Core Client
-
Java 8 client for easy work with Payment Core API.

Technical details
-
The client makes usage of CompletableFuture, which is return type wrapper of all the methods and thus written in asynchronous, non-blocking fashion. Result can be retrieved eather by the time its available, or immediatelly, based on application demands. In case of http failures, HttpConnectionException is thrown to the CompletableFuture block or to the main thread with the information about error status code and response body.

Usage examples
-
- <b>Create client instance</b><br/> 
```
//create new instance each time could be resource heavy, idealy this should be done only once per application
PaymentCoreClientAsync client = new PaymentCoreClientAsync("partner_id", "secret_key");
```
- <b>Method call and handling result</b><br/>
```
public CompletableFuture<String> createPreTransaction(PreTransactionRequest preTransactionRequest) 
PreTransactionRequest req = .... //feed object with data
```

- non-blocking (see Notes below)
```
t.createPreTransaction(req)
    .exceptionally(ex -> {
        //do something when exception occurs
        //ex here is instance of CompletionException
        //ex.getCause() is the cause of CompletitionException, i.e. HttpConnectionException
        HttpConnectionException hce = (HttpConnectionException)ex.getCause();
        //HttpConnectionException contains error http status code and response body
    return null; //some value (of the same type as the return type - String in our example) must be returned to the next stage
}) .thenAccept((String res) -> {
    if (res != null) 
    //do something when result is returned. This stage will run even if exception is thrown and caught by exceptionally stage
});
```


- The exception thrown into Future block is always of class java.util.concurrent.CompletionException which wraps the more interesting 'cause Exception' - see example below. 
- Exceptions thrown into the CompletagleFuture flow doesn't happen in the main thread. That said, if .exceptionally stage is skipped, Exception will invisibly pass away and even .thenAccept stage will not trigger. Surrounding CompletableFuture with try-catch block will not see exception eather.
Exceptional block must return some value for the next stage (thenAccept in the example) and that stage will be processed as well. 

- `getTransactionByReferenceId` handles internal Http redirect in a way that it waits for http response with redirect status and uses it's Location header to perform another http call, which is asynchronous again. In this case, CompletionException could be thrown to the main thread (in case of HttpConnectionException) as well as to the exceptional block (case of JsonParserException):
```
try {
    t.getTransactionByReferenceId("ref_id")
        .exceptionally(ex -> {
            //handle stage exception
            return null;
        })
        .thenAccept(res -> {
            if (res != null) ....//handle result
        }
    } catch (Exception e) {
        //handle exception in the main thread
}
```
- blocking - blocks the main thread until result is returned. Exception is thrown to the main thread and should be caught
```
try {
    String preTransactionId = t.createPreTransaction(req).join();
} catch (CompletitionException ce) {
    if (ce.getCause() instanceOf HttpConnectionException) {
        HttpConnectionException hce = (HttpConnectionException)ex.getCause();
        ...
    }     
}
```
- exceptions<br/>
`HttpConnectionException` API returns error Http status code<br/>
`JsonParserException` serialize / deserialize errors